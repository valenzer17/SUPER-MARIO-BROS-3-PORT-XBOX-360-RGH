------------ES----------------------------

SUPER MARIO BROS. 3 - XBOX 360 -  construido sobre xsdk

COMO PROBARLO (RGH/JTAG)
1. Copia la carpeta SMB3 completa a tu consola (por ejemplo Hdd1:\Games\SMB3\ por FTP).
   Debe contener: default.xex y smb3.nes (mismo nombre, en minusculas, en la misma carpeta).
2. En Aurora: Ajustes > Rutas de escaneo (Scan Path), agrega la carpeta y escanea. Abrelo desde ahi.
   (Si Aurora no lo lista, ejecuta default.xex desde su explorador de archivos.)

QUE DEBERIA PASAR
- Entra directo al juego (pantalla de titulo de SMB3), .
- Control 1 y 2: A = A, X o B = B, START = Start, BACK = Select, cruz o stick izquierdo.
- Mantener START + BACK 2,5 segundos vuelve a Aurora. El boton Guide tambien funciona.
- Si no encuentra smb3.nes, la pantalla se pone ROJA unos 5 segundos y vuelve a Aurora.

------------EN---------------------------

SUPER MARIO BROS. 3 - XBOX 360 - Built on xsdk

HOW TO TEST IT (RGH/JTAG)
1. Copy the entire SMB3 folder to your console (for example, Hdd1:\Games\SMB3\ via FTP).
It should contain: default.xex and smb3.nes (same name, lowercase, in the same folder).

2. In Aurora: Settings > Scan Path, add the folder and scan. Open it from there. Open it from there.

(If Aurora doesn't list it, run default.xex from your file explorer.)

WHAT SHOULD HAPPEN
- Go directly to the game (SMB3 title screen).

- Controls 1 and 2: A = A, X or B = B, START = Start, BACK = Select, D-pad, or left stick.

- Hold START + BACK for 2.5 seconds Return to Aurora. The Guide button also works.
 If it cannot find smb3.nes, the screen will turn RED for about 5 seconds and then return to Aurora.




.


