// Puente entre el nucleo de FCEUX y el frontend de xsdk. Aqui viven las funciones FCEUD_* que el nucleo
// espera de la plataforma; el frontend solo ve la API en C del final.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include "types.h"
#include "fceu.h"
#include "driver.h"
#include "file.h"
#include "emufile.h"
#include "netplay.h"
#include "input.h"

extern "C" void xsdk_log_write(const char *format, ...);

struct pcpal { unsigned char r, g, b; };
static pcpal pcpalette[256];

FCEUFILE* FCEUD_OpenArchiveIndex(ArchiveScanRecord&, std::string&, int) { return 0; }
FCEUFILE* FCEUD_OpenArchive(ArchiveScanRecord&, std::string&, std::string*) { return 0; }
ArchiveScanRecord FCEUD_ScanArchive(std::string) { return ArchiveScanRecord(); }
void FCEUD_SetPalette(unsigned char i, unsigned char r, unsigned char g, unsigned char b) { pcpalette[i].r = r; pcpalette[i].g = g; pcpalette[i].b = b; }
void FCEUD_GetPalette(unsigned char i, unsigned char *r, unsigned char *g, unsigned char *b) { *r = pcpalette[i].r; *g = pcpalette[i].g; *b = pcpalette[i].b; }
FILE *FCEUD_UTF8fopen(const char *n, const char *m) { return fopen(n, m); }
EMUFILE_FILE* FCEUD_UTF8_fstream(const char *n, const char *m) { return new EMUFILE_FILE(n, m); }
bool FCEUD_ShouldDrawInputAids() { return false; }
void FCEUD_VideoChanged() {}
void FCEUD_PrintError(const char *s) { xsdk_log_write("nes error: %s", s); }
void FCEUD_Message(const char *s) { xsdk_log_write("nes: %s", s); }
void FCEUD_NetworkClose(void) {}
bool FCEUD_PauseAfterPlayback() { return false; }
void FCEUD_SetEmulationSpeed(int) {}
void FCEUD_SetInput(bool, bool, ESI, ESI, ESIFC) {}
void FCEUD_HideMenuToggle(void) {} void FCEUD_TurboOn(void) {} void FCEUD_TurboOff(void) {} void FCEUD_TurboToggle(void) {}
void FCEUD_SaveStateAs(void) {} void FCEUD_LoadStateFrom(void) {} void FCEUD_MovieRecordTo(void) {} void FCEUD_MovieReplayFrom(void) {}
void FCEUD_ToggleStatusIcon(void) {} void FCEUD_SoundToggle(void) {} void FCEUD_AviRecordTo(void) {} void FCEUD_AviStop(void) {}
void FCEUI_AviVideoUpdate(const unsigned char*) {}
int FCEUD_ShowStatusIcon(void) { return 0; }
bool FCEUI_AviIsRecording(void) { return 0; }
bool FCEUI_AviDisableMovieMessages() { return true; }
const char *FCEUD_GetCompilerString() { return NULL; }
void FCEUI_UseInputPreset(int) {}
void FCEUD_SoundVolumeAdjust(int) {}
bool turbo = false;
int FCEUnetplay = 0;
void NetplayUpdate(uint8*) {}
int FCEUNET_SendCommand(uint8, uint32) { return 1; }
int closeFinishedMovie = 0;
volatile int datacount = 0, undefinedcount = 0;
unsigned char *cdloggerdata = 0;
int GetPRGAddress(int) { return -1; }

extern uint8 *XBuf;
static uint32 s_pad = 0;

extern "C" {

// 0 si cargo bien.
int nes_start(const char *rom)
{
	if (!FCEUI_Initialize())
		return 1;
	FCEUI_SetBaseDirectory("game:/");
	FCEUI_Sound(48000);
	FCEUI_SetVidSystem(0);
	if (!FCEUI_LoadGame(rom, 0))
		return 2;
	FCEUI_SetInput(0, SI_GAMEPAD, (void *)&s_pad, 0);
	FCEUI_SetInput(1, SI_GAMEPAD, (void *)&s_pad, 0);
	return 0;
}

// pads: bits A=1 B=2 SELECT=4 START=8 UP=16 DOWN=32 LEFT=64 RIGHT=128.
void nes_run_frame(uint32_t pad1, uint32_t pad2, const uint8_t **pixels, const int32_t **sound, int32_t *sound_count)
{
	uint8 *gfx = 0;
	int32 *snd = 0;
	int32 count = 0;
	s_pad = (pad1 & 0xFF) | ((pad2 & 0xFF) << 8);
	FCEUI_Emulate(&gfx, &snd, &count, 0);
	*pixels = XBuf ? XBuf : gfx;
	*sound = snd;
	*sound_count = count;
}

// Color i como lo espera el buffer de la consola: 0xBBGGRRAA (docs/HARDWARE.md).
uint32_t nes_palette_word(uint8_t i)
{
	return ((uint32_t)pcpalette[i].b << 24) | ((uint32_t)pcpalette[i].g << 16) | ((uint32_t)pcpalette[i].r << 8) | 0xFF;
}

void nes_shutdown(void)
{
	FCEUI_CloseGame();
	FCEUI_Kill();
}

}
