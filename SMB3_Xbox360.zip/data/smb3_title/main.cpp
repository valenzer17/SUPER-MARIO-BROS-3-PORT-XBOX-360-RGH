// Super Mario Bros. 3 para Xbox 360 (modo kiosco): entra directo al juego, sin menus ni buscador de ROMs.
// Nucleo: FCEUX. Plataforma: xsdk (video por el buffer de pantalla, audio, control).
// START + BACK mantenidos 2,5 s vuelven al dashboard.
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

extern "C" {
#include "xsdk/audio.h"
#include "xsdk/gpu.h"
#include "xsdk/kernel.h"
#include "xsdk/log.h"
#include "xsdk/present.h"
#include "xsdk/thread.h"
#include "xsdk/xam.h"

int nes_start(const char *rom);
void nes_run_frame(uint32_t pad1, uint32_t pad2, const uint8_t **pixels, const int32_t **sound, int32_t *count);
uint32_t nes_palette_word(uint8_t i);
void nes_shutdown(void);
}

#define ROM_PATH "game:/smb3.nes"

enum {
	SCREEN_W = 1280,
	SCREEN_H = 720,
	SCALE = 3,
	NES_W = 256,
	NES_H = 240,
	X0 = (SCREEN_W - NES_W * SCALE) / 2,
	BUFFERS = 3,
	EXIT_HOLD_FRAMES = 150, // 2,5 s a 60 Hz
	STICK_DEADZONE = 16000,
	RING_SIZE = 16384, // muestras mono, potencia de 2
	RING_MASK = RING_SIZE - 1,
	MAX_QUEUED = 4096, // mas que esto, se descarta audio nuevo para no acumular retraso
};

// Direccion en el layout de tiles de 32x32 que lee la pantalla (docs/HARDWARE.md, libxenon console.c).
static uint32_t g_xpart[SCREEN_W];
static uint32_t g_ypart[SCREEN_H];
static uint32_t g_palette[256];

static void build_tables(void)
{
	for (uint32_t x = 0; x < SCREEN_W; x++)
		g_xpart[x] = ((x >> 5) << 10) + (x & 3) + (((x & 31) >> 2) << 3);
	for (uint32_t y = 0; y < SCREEN_H; y++)
		g_ypart[y] = (y >> 5) * 32 * SCREEN_W + ((y & 1) << 2) + (((y & 31) >> 1) << 6);
	for (uint32_t i = 0; i < 256; i++)
		g_palette[i] = nes_palette_word((uint8_t)i);
}

static void blit(volatile uint32_t *px, const uint8_t *nes)
{
	uint32_t row[NES_W];
	for (uint32_t sy = 0; sy < SCREEN_H; sy++) {
		if (sy % SCALE == 0) {
			const uint8_t *src = nes + (sy / SCALE) * NES_W;
			for (uint32_t x = 0; x < NES_W; x++)
				row[x] = g_palette[src[x]];
		}
		const uint32_t yp = g_ypart[sy];
		const uint32_t flip = (sy & 8) << 2;
		for (uint32_t x = 0; x < NES_W; x++) {
			const uint32_t word = row[x];
			const uint32_t base = X0 + x * SCALE;
			px[(g_xpart[base] + yp) ^ flip] = word;
			px[(g_xpart[base + 1] + yp) ^ flip] = word;
			px[(g_xpart[base + 2] + yp) ^ flip] = word;
		}
	}
}

// ---- audio: un hilo lleva las muestras del emulador al kernel, 256 por cuadro ----
static int16_t g_ring[RING_SIZE];
static volatile uint32_t g_write;
static volatile uint32_t g_read;
static volatile bool g_audio_run = true;

static uint32_t audio_thread(void *)
{
	while (g_audio_run) {
		float *frame = 0;
		const NTSTATUS status = xsdk_audio_next_frame(100, &frame);
		if (!NT_SUCCESS(status) || !frame)
			continue;
		__sync_synchronize();
		const uint32_t avail = g_write - g_read;
		const uint32_t rd = g_read;
		for (uint32_t i = 0; i < XSDK_AUDIO_FRAME_SAMPLES; i++) {
			const float v = i < avail ? (float)g_ring[(rd + i) & RING_MASK] * (1.0f / 32768.0f) : 0.0f;
			for (uint32_t c = 0; c < XSDK_AUDIO_CHANNELS; c++)
				frame[c * XSDK_AUDIO_FRAME_SAMPLES + i] = (c == XSDK_AUDIO_FRONT_LEFT || c == XSDK_AUDIO_FRONT_RIGHT) ? v : 0.0f;
		}
		g_read = rd + (avail < XSDK_AUDIO_FRAME_SAMPLES ? avail : XSDK_AUDIO_FRAME_SAMPLES);
		xsdk_audio_queue_frame();
	}
	return 0;
}

static void push_audio(const int32_t *snd, int32_t count)
{
	if (!snd || count <= 0)
		return;
	if (g_write - g_read > MAX_QUEUED)
		return;
	uint32_t w = g_write;
	for (int32_t i = 0; i < count; i++) {
		int32_t s = snd[i];
		if (s > 32767) s = 32767;
		if (s < -32768) s = -32768;
		g_ring[w++ & RING_MASK] = (int16_t)s;
	}
	__sync_synchronize();
	g_write = w;
}

// ---- control: A=A, X/B=B, START=Start, BACK=Select, cruz y stick izquierdo ----
static uint32_t read_pad(uint32_t user, uint16_t *raw)
{
	INPUT_STATE st;
	memset(&st, 0, sizeof st);
	if (XamInputGetState(user, 0, &st) != ERROR_SUCCESS) {
		if (raw) *raw = 0;
		return 0;
	}
	const uint16_t b = st.gamepad.buttons;
	if (raw) *raw = b;
	uint32_t m = 0;
	if (b & INPUT_GAMEPAD_A) m |= 1;
	if (b & (INPUT_GAMEPAD_B | INPUT_GAMEPAD_X)) m |= 2;
	if (b & INPUT_GAMEPAD_BACK) m |= 4;
	if (b & INPUT_GAMEPAD_START) m |= 8;
	if ((b & INPUT_GAMEPAD_DPAD_UP) || st.gamepad.thumb_ly > STICK_DEADZONE) m |= 16;
	if ((b & INPUT_GAMEPAD_DPAD_DOWN) || st.gamepad.thumb_ly < -STICK_DEADZONE) m |= 32;
	if ((b & INPUT_GAMEPAD_DPAD_LEFT) || st.gamepad.thumb_lx < -STICK_DEADZONE) m |= 64;
	if ((b & INPUT_GAMEPAD_DPAD_RIGHT) || st.gamepad.thumb_lx > STICK_DEADZONE) m |= 128;
	return m;
}

static void clear_buffers(void)
{
	for (uint32_t i = 0; i < BUFFERS; i++) {
		volatile uint32_t *px = xsdk_present_pixels(xsdk_present_buffer_address(i));
		memset((void *)px, 0, SCREEN_W * 736 * 4);
	}
}

// Pinta la pantalla de un color y espera: la unica señal visible si algo falla al arrancar.
static void show_error_color(uint32_t word, uint32_t frames)
{
	for (uint32_t f = 0; f < frames; f++) {
		uint32_t address;
		if (!NT_SUCCESS(xsdk_present_begin(&address, 5000)))
			return;
		volatile uint32_t *px = xsdk_present_pixels(address);
		for (uint32_t i = 0; i < SCREEN_W * 736; i++)
			px[i] = word;
		xsdk_present_end();
	}
}

int main(void)
{
	xsdk_log_write("smb3: inicio");
	NTSTATUS status = xsdk_gpu_open();
	if (!NT_SUCCESS(status)) {
		xsdk_log_write("smb3: xsdk_gpu_open fallo: 0x%08X", (unsigned)status);
		return 1;
	}
	uint32_t width = 0, height = 0;
	status = xsdk_present_open(XSDK_DISPLAY_720P, BUFFERS, 1, &width, &height);
	if (!NT_SUCCESS(status)) {
		xsdk_log_write("smb3: xsdk_present_open fallo: 0x%08X", (unsigned)status);
		return 1;
	}
	xsdk_log_write("smb3: pantalla %ux%u", (unsigned)width, (unsigned)height);
	clear_buffers();

	const int started = nes_start(ROM_PATH);
	if (started != 0) {
		xsdk_log_write("smb3: no se pudo cargar %s (codigo %d)", ROM_PATH, started);
		show_error_color(0x0000FFFFu /* rojo */, 300);
		xsdk_present_close();
		xsdk_gpu_close();
		return 2;
	}
	build_tables();

	HANDLE audio = 0;
	status = xsdk_audio_open(0);
	if (NT_SUCCESS(status)) {
		if (!NT_SUCCESS(xsdk_thread_create(&audio, 0, audio_thread, 0)))
			xsdk_log_write("smb3: no se pudo crear el hilo de audio");
	} else {
		xsdk_log_write("smb3: xsdk_audio_open fallo: 0x%08X", (unsigned)status);
	}

	const uint8_t *pixels = 0;
	uint32_t exit_frames = 0;
	bool have_frame = false;
	for (;;) {
		uint32_t address;
		status = xsdk_present_begin(&address, 5000);
		if (!NT_SUCCESS(status)) {
			xsdk_log_write("smb3: xsdk_present_begin fallo: 0x%08X", (unsigned)status);
			break;
		}
		if (!xsdk_system_ui_open()) {
			uint16_t raw0 = 0;
			const uint32_t p1 = read_pad(0, &raw0);
			const uint32_t p2 = read_pad(1, 0);
			const int32_t *snd = 0;
			int32_t count = 0;
			nes_run_frame(p1, p2, &pixels, &snd, &count);
			push_audio(snd, count);
			have_frame = pixels != 0;
			const uint16_t both = INPUT_GAMEPAD_START | INPUT_GAMEPAD_BACK;
			exit_frames = (raw0 & both) == both ? exit_frames + 1 : 0;
		}
		if (have_frame)
			blit(xsdk_present_pixels(address), pixels);
		xsdk_present_end();
		if (exit_frames >= EXIT_HOLD_FRAMES)
			break;
	}

	g_audio_run = false;
	if (audio)
		xsdk_audio_close();
	nes_shutdown();
	xsdk_present_close();
	xsdk_gpu_close();
	xsdk_log_write("smb3: fin");
	return 0;
}
