/* FCE Ultra - NES/Famicom Emulator
 *
 * Copyright notice for this file:
 *  Copyright (C) 2002 Xodnizel
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _SOUND_H_
#define _SOUND_H_

typedef struct {
	   void (*Fill)(int Count);	/* Low quality ext sound. */

	   /* NeoFill is for sound devices that are emulated in a more
	      high-level manner(VRC7) in HQ mode.  Interestingly, 
	      this device has slightly better sound quality(updated more
	      often) in lq mode than in high-quality mode.  Maybe that
     	      should be fixed. :)
	   */
           void (*NeoFill)(int32 *Wave, int Count);
	   void (*HiFill)(void);
	   void (*HiSync)(int32 ts);

	   void (*RChange)(void);
	   void (*Kill)(void);
} EXPSOUND;

extern EXPSOUND GameExpSound;

extern int32 nesincsize;

void SetSoundVariables(void);

int GetSoundBuffer(int32 **W);
int FlushEmulateSound(void);
extern int32 Wave[2048+512];
extern int32 WaveFinal[2048+512];
extern int32 WaveHi[];
extern uint32 soundtsinc;

#ifdef WIN32
extern volatile int datacount, undefinedcount;
extern int debug_loggingCD;
extern unsigned char *cdloggerdata;
#endif

extern uint32 soundtsoffs;
#define SOUNDTS (timestamp + soundtsoffs)

// Channel state access for Lua API
extern uint8 EnabledChannels;
extern int32 lengthcount[4];
extern int32 DMCSize;
extern uint8 PSG[0x10];
extern uint8 DMCFormat;
extern uint8 DMCAddressLatch;
extern uint8 DMCSizeLatch;
extern uint8 RawDALatch;
extern int32 ChannelLastSample[5];  // Last sample from each channel (0=Pulse1, 1=Pulse2, 2=Triangle, 3=Noise, 4=DMC)
extern int32 ChannelSampleBuffer[5][512];  // Circular buffer of recent samples for each channel (for FFT)
extern int ChannelSampleBufferIndex[5];  // Current write index for each channel buffer

void SetNESSoundMap(void);
void FrameSoundUpdate(void);

void FCEUSND_Power(void);
void FCEUSND_Reset(void);
void FCEUSND_SaveState(void);
void FCEUSND_LoadState(int version);

void FCEU_SoundCPUHook(int);
void Write_IRQFM (uint32 A, uint8 V); //mbg merge 7/17/06 brought over from latest mmbuild

void LogDPCM(int romaddress, int dpcmsize);

// Audio output filter control (for Lua API)
void SetAudioOutputFilter(bool enabled, int filterType, double cutoff, double q);
void GetAudioOutputFilter(bool* enabled, int* filterType, double* cutoff, double* q);

#endif
