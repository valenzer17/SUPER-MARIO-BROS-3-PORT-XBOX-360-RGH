/* FCE Ultra - NES/Famicom Emulator
*
* Copyright notice for this file:
*  Copyright (C) 2002 Xodnizel
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "x6502.h"
#include "fceu.h"
#include "fds.h"
#include "sound.h"
#include "file.h"
#include "utils/md5.h"
#include "utils/memory.h"
#include "state.h"
#include "file.h"
#include "cart.h"
#include "netplay.h"
#include "driver.h"
#include "movie.h"

//  TODO:  Add code to put a delay in between the time a disk is inserted
//	and the when it can be successfully read/written to.  This should
//	prevent writes to wrong places OR add code to prevent disk ejects
//	when the virtual motor is on(mmm...virtual motor).
extern int disableBatteryLoading; 

bool isFDS = false;	//flag for determining if a FDS game is loaded, movie.cpp needs this

static DECLFR(FDSRead4030);
static DECLFR(FDSRead4031);
static DECLFR(FDSRead4032);
static DECLFR(FDSRead4033);

static DECLFW(FDSWrite);

static DECLFW(FDSWaveWrite);
static DECLFR(FDSWaveRead);

static DECLFR(FDSSRead);
static DECLFW(FDSSWrite);
static DECLFR(FDSBIOSRead);
static DECLFR(FDSRAMRead);
static DECLFW(FDSRAMWrite);
static void FDSInit(void);
static void FDSFix(int a);

#define FDSRAM GameMemBlock
#define CHRRAM (GameMemBlock+32768)

static uint8 FDSRegs[6];
static uint8 FDSReg4026;  // External connector output register
static int32 IRQLatch,IRQCount;
static uint8 IRQa;
static void FDSClose(void);

#if defined(GEKKO)|defined(_XBOX)
uint8 FDSBIOS[8192];
#else
static uint8 FDSBIOS[8192];
#endif

/* Original disk data backup, to help in creating save states. */
static uint8 *diskdatao[8]={0,0,0,0,0,0,0,0};

static uint8 *diskdata[8]={0,0,0,0,0,0,0,0};

static int TotalSides; //mbg merge 7/17/06 - unsignedectomy
static uint8 DiskWritten=0;    /* Set to 1 if disk was written to. */
static uint8 writeskip;
static uint32 DiskPtr;
static int32 DiskSeekIRQ;
static uint8 SelectDisk,InDisk;
static uint8 ByteTransferFlag;  // Bit 7 of $4030 - set when 8 bits transferred

#define DC_INC    1

void FDSGI(GI h)
{
	switch(h)
	{
	case GI_CLOSE: FDSClose();break;
	case GI_POWER: FDSInit();break;
	}
}

static void FDSStateRestore(int version)
{ 
	int x;

	setmirror(((FDSRegs[5]&8)>>3)^1);

	if(version >= 9810)
		for(x=0;x<TotalSides;x++)
		{
			int b;
			for(b=0; b<65500; b++)
				diskdata[x][b] ^= diskdatao[x][b];
		}

}

void FDSSound();
void FDSSoundReset(void);
void FDSSoundStateAdd(void);
static void RenderSound(void);
static void RenderSoundHQ(void);

static void FDSInit(void)
{
	memset(FDSRegs,0,sizeof(FDSRegs));
	FDSReg4026=0xFF;  // External connector: all bits pulled high initially
	writeskip=DiskPtr=DiskSeekIRQ=0;
	ByteTransferFlag=0;
	setmirror(1);

	setprg8r(0,0xe000,0);    // BIOS
	setprg32r(1,0x6000,0);   // 32KB RAM
	setchr8(0);     // 8KB CHR RAM

	MapIRQHook=FDSFix;
	GameStateRestore=FDSStateRestore;

	SetReadHandler(0x4030,0x4030,FDSRead4030);
	SetReadHandler(0x4031,0x4031,FDSRead4031);
	SetReadHandler(0x4032,0x4032,FDSRead4032);
	SetReadHandler(0x4033,0x4033,FDSRead4033);

	SetWriteHandler(0x4020,0x4026,FDSWrite);  // Extended to include $4026

	SetWriteHandler(0x6000,0xdfff,FDSRAMWrite);
	SetReadHandler(0x6000,0xdfff,FDSRAMRead);
	SetReadHandler(0xE000,0xFFFF,FDSBIOSRead);
	IRQCount=IRQLatch=IRQa=0;

	FDSSoundReset();
	InDisk=0;
	SelectDisk=0;
}

void FCEU_FDSInsert(void)
{
	if(FCEUI_EmulationPaused()) EmulationPaused |= 2;

	if(FCEUMOV_Mode(MOVIEMODE_RECORD))
		FCEUMOV_AddCommand(FCEUNPCMD_FDSINSERT);

	if(TotalSides==0)
	{
		FCEU_DispMessage("Not FDS; can't eject disk.",0);  
		return;
	}
	if(InDisk==255)
	{
		FCEU_DispMessage("Disk %d Side %s Inserted",0,SelectDisk>>1,(SelectDisk&1)?"B":"A");  
		InDisk=SelectDisk;
	}
	else   
	{
		FCEU_DispMessage("Disk %d Side %s Ejected",0,SelectDisk>>1,(SelectDisk&1)?"B":"A");
		InDisk=255;
	}
}
/*
void FCEU_FDSEject(void)
{
InDisk=255;
}
*/
void FCEU_FDSSelect(void)
{
	if(FCEUI_EmulationPaused()) EmulationPaused |= 2;

	if(FCEUMOV_Mode(MOVIEMODE_RECORD))
		FCEUMOV_AddCommand(FCEUNPCMD_FDSSELECT);

	if(TotalSides==0)
	{
		FCEU_DispMessage("Not FDS; can't select disk.",0);
		return;
	}
	if(InDisk!=255)
	{
		FCEU_DispMessage("Eject disk before selecting.",0);
		return;
	}
	SelectDisk=((SelectDisk+1)%TotalSides)&3;
	FCEU_DispMessage("Disk %d Side %c Selected",0,SelectDisk>>1,(SelectDisk&1)?'B':'A');
}

static void FDSFix(int a)
{
	// Timer IRQ: only active if disk registers are enabled ($4023.0) and timer is enabled
	if((IRQa&2) && IRQCount && (FDSRegs[3]&0x1))
	{
		IRQCount-=a;
		if(IRQCount<=0)
		{
			if(!(IRQa&1))
			{
				IRQa&=~2;
				IRQCount=IRQLatch=0;
			}
			else
				IRQCount=IRQLatch; 
			X6502_IRQBegin(FCEU_IQEXT);
		}
	}
	// Disk transfer IRQ
	if(DiskSeekIRQ>0) 
	{
		DiskSeekIRQ-=a;
		if(DiskSeekIRQ<=0)
		{
			if(FDSRegs[5]&0x80 && (FDSRegs[3]&0x1))
			{
				X6502_IRQBegin(FCEU_IQEXT2);
			}
		}
	}
}

static DECLFR(FDSRead4030)
{
	uint8 ret=0;

	// Bit 0: Timer Interrupt (1 = IRQ occurred)
	if(X.IRQlow&FCEU_IQEXT) ret|=1;
	
	// Bit 1: Unknown Interrupt source (TODO)
	// Bit 2: Nametable Arrangement (from $4025.D3)
	if(FDSRegs[5]&0x08) ret|=4;
	
	// Bit 3: CRC control (0 = CRC passed, 1 = CRC error)
	// TODO: Implement proper CRC checking
	
	// Bit 4: End of Head (1 when disk head is on most inner track)
	// TODO: Track disk head position
	
	// Bit 5: Unknown
	
	// Bit 6: Unknown
	
	// Bit 7: Byte transfer flag - set every time 8 bits transferred,
	//        reset when $4024, $4031, or $4030 is serviced
	ret |= ByteTransferFlag;
	
	// Reading $4030 resets the byte transfer flag and acknowledges IRQs
	if(!fceuindbg)
	{
		ByteTransferFlag = 0;
		X6502_IRQEnd(FCEU_IQEXT);
		X6502_IRQEnd(FCEU_IQEXT2);
	}
	return ret;
}

static DECLFR(FDSRead4031)
{
	static uint8 z=0;
	if(InDisk!=255)
	{
		z=diskdata[InDisk][DiskPtr];
		if(!fceuindbg)
		{
			if(DiskPtr<64999) DiskPtr++;
			DiskSeekIRQ=150;
			// Reading $4031 resets byte transfer flag and acknowledges disk IRQ
			ByteTransferFlag = 0;
			X6502_IRQEnd(FCEU_IQEXT2);
		}
	}
	return z;
}
static DECLFR(FDSRead4032)
{       
	uint8 ret = X.DB & ~7;  // Preserve upper bits

	// Disk flag (bit 0): 0 = Disk inserted, 1 = Disk not inserted
	if(InDisk==255)
		ret|=1;  // No disk inserted

	// Ready flag (bit 1): 0 = Disk ready, 1 = Disk not ready
	// Set when head reaches end of disk, cleared when returns to start
	// Motor must be on (bit 4 of $4025 is 0) and disk must be inserted
	if(InDisk==255 || (FDSRegs[5]&0x10))        
		ret|=2;  // Not ready (motor off or disk ejected)

	// Protect flag (bit 2): 0 = Not write protected, 1 = Write protected or disk ejected
	// For now, assume not write protected unless disk is ejected
	if(InDisk==255)
		ret|=4;  // Write protected (no disk)

	// Acknowledge disk IRQ
	if(!fceuindbg)
		X6502_IRQEnd(FCEU_IQEXT2);

	return ret;
}

static DECLFR(FDSRead4033)
{
	uint8 ret = 0;

	// Bits 0-6: Input from expansion terminal (read from $4026 output)
	// Open-collector: if bit is clear in $4026, it reads as '0' here
	ret = FDSReg4026 & 0x7F;  // Lower 7 bits from $4026

	// Bit 7: Battery status (0 = Voltage is low, 1 = Good)
	// Should be checked when motor is on, otherwise always reads as 0
	// For now, assume battery is good if motor is on
	if((FDSRegs[5]&0x10)==0)  // Motor is on (bit 4 of $4025 is 0)
		ret |= 0x80;  // Battery good

	return ret;
}

static DECLFW(FDSRAMWrite)
{
	(FDSRAM-0x6000)[A]=V;
}

static DECLFR(FDSBIOSRead)
{
	return (FDSBIOS-0xE000)[A];
}

static DECLFR(FDSRAMRead)
{
	return (FDSRAM-0x6000)[A];
}

/* Begin FDS sound */

#define FDSClock (1789772.7272727272727272/2)

typedef struct {
	int64 cycles;     // Cycles per PCM sample
	int64 count;    // Cycle counter
	int64 envcount;    // Envelope cycle counter
	uint32 b19shiftreg60;
	uint32 b24adder66;
	uint32 b24latch68;
	uint32 b17latch76;
	int32 clockcount;  // Counter to divide frequency by 8.
	uint8 b8shiftreg88;  // Modulation register.
	uint8 amplitude[2];  // Current amplitudes.
	uint8 speedo[2];
	uint8 mwcount;
	uint8 mwstart;
	uint8 mwave[0x20];      // Modulation waveform
	uint8 cwave[0x40];      // Game-defined waveform(carrier)
	uint8 SPSG[0xB];
} FDSSOUND;

static FDSSOUND fdso;

#define  SPSG  fdso.SPSG
#define b19shiftreg60  fdso.b19shiftreg60
#define b24adder66  fdso.b24adder66
#define b24latch68  fdso.b24latch68
#define b17latch76  fdso.b17latch76
#define b8shiftreg88  fdso.b8shiftreg88
#define clockcount  fdso.clockcount
#define amplitude  fdso.amplitude
#define speedo    fdso.speedo

void FDSSoundStateAdd(void)
{
	AddExState(fdso.cwave,64,0,"WAVE");
	AddExState(fdso.mwave,32,0,"MWAV");
	AddExState(amplitude,2,0,"AMPL");
	AddExState(SPSG,0xB,0,"SPSG");

	AddExState(&b8shiftreg88,1,0,"B88");

	AddExState(&clockcount, 4, 1, "CLOC");
	AddExState(&b19shiftreg60,4,1,"B60");
	AddExState(&b24adder66,4,1,"B66");
	AddExState(&b24latch68,4,1,"B68");
	AddExState(&b17latch76,4,1,"B76");

}

static DECLFR(FDSSRead)
{
	switch(A&0xF)
	{
	case 0x0:return(amplitude[0]|(X.DB&0xC0));
	case 0x2:return(amplitude[1]|(X.DB&0xC0));
	}
	return(X.DB);
}

static DECLFW(FDSSWrite)
{
	if(FSettings.SndRate)
	{
		if(FSettings.soundq>=1)
			RenderSoundHQ();
		else
			RenderSound();
	}
	A-=0x4080;
	switch(A)
	{
	case 0x0: 
	case 0x4: if(V&0x80)
				  amplitude[(A&0xF)>>2]=V&0x3F; //)>0x20?0x20:(V&0x3F);
		break;
	case 0x5://printf("$%04x:$%02x\n",A,V);
		break;
	case 0x7: b17latch76=0;SPSG[0x5]=0;//printf("$%04x:$%02x\n",A,V);
		break;
	case 0x8:
		b17latch76=0;
		//   printf("%d:$%02x, $%02x\n",SPSG[0x5],V,b17latch76);
		fdso.mwave[SPSG[0x5]&0x1F]=V&0x7;
		SPSG[0x5]=(SPSG[0x5]+1)&0x1F;
		break;
	}
	//if(A>=0x7 && A!=0x8 && A<=0xF)
	//if(A==0xA || A==0x9) 
	//printf("$%04x:$%02x\n",A,V);
	SPSG[A]=V;
}

// $4080 - Fundamental wave amplitude data register 92
// $4082 - Fundamental wave frequency data register 58
// $4083 - Same as $4082($4083 is the upper 4 bits).

// $4084 - Modulation amplitude data register 78
// $4086 - Modulation frequency data register 72
// $4087 - Same as $4086($4087 is the upper 4 bits)


static void DoEnv()
{
	int x;

	for(x=0;x<2;x++)
		if(!(SPSG[x<<2]&0x80) && !(SPSG[0x3]&0x40))
		{
			static int counto[2]={0,0};

			if(counto[x]<=0)
			{
				if(!(SPSG[x<<2]&0x80))
				{
					if(SPSG[x<<2]&0x40)
					{
						if(amplitude[x]<0x3F)
							amplitude[x]++;
					}
					else
					{
						if(amplitude[x]>0)
							amplitude[x]--;
					}
				}
				counto[x]=(SPSG[x<<2]&0x3F);
			}
			else
				counto[x]--;
		}
}

static DECLFR(FDSWaveRead)
{
	return(fdso.cwave[A&0x3f]|(X.DB&0xC0));
}

static DECLFW(FDSWaveWrite)
{
	//printf("$%04x:$%02x, %d\n",A,V,SPSG[0x9]&0x80);
	if(SPSG[0x9]&0x80)
		fdso.cwave[A&0x3f]=V&0x3F;
}

static int ta;
static INLINE void ClockRise(void)
{
	if(!clockcount)
	{
		ta++;

		b19shiftreg60=(SPSG[0x2]|((SPSG[0x3]&0xF)<<8));
		b17latch76=(SPSG[0x6]|((SPSG[0x07]&0xF)<<8))+b17latch76;

		if(!(SPSG[0x7]&0x80)) 
		{
			int t=fdso.mwave[(b17latch76>>13)&0x1F]&7;
			int t2=amplitude[1];
			int adj = 0;

			if((t&3))
			{
				if((t&4))
					adj -= (t2 * ((4 - (t&3) ) ));
				else
					adj += (t2 * ( (t&3) ));
			}
			adj *= 2;
			if(adj > 0x7F) adj = 0x7F;
			if(adj < -0x80) adj = -0x80;
			//if(adj) printf("%d ",adj);
			b8shiftreg88=0x80 + adj;
		}
		else
		{ 
			b8shiftreg88=0x80;
		}
	}
	else
	{
		b19shiftreg60<<=1;  
		b8shiftreg88>>=1;
	}
	// b24adder66=(b24latch68+b19shiftreg60)&0x3FFFFFF;
	b24adder66=(b24latch68+b19shiftreg60)&0x1FFFFFF;
}

static INLINE void ClockFall(void)
{
	//if(!(SPSG[0x7]&0x80))
	{
		if((b8shiftreg88&1)) // || clockcount==7)
			b24latch68=b24adder66;
	}
	clockcount=(clockcount+1)&7;
}

static INLINE int32 FDSDoSound(void)
{
	fdso.count+=fdso.cycles;
	if(fdso.count>=((int64)1<<40))
	{
dogk:
		fdso.count-=(int64)1<<40;
		ClockRise();
		ClockFall();
		fdso.envcount--;
		if(fdso.envcount<=0)
		{
			fdso.envcount+=SPSG[0xA]*3;
			DoEnv(); 
		}
	}
	if(fdso.count>=32768) goto dogk;

	// Might need to emulate applying the amplitude to the waveform a bit better...
	{
		int k=amplitude[0];
		if(k>0x20) k=0x20;
		return (fdso.cwave[b24latch68>>19]*k)*4/((SPSG[0x9]&0x3)+2);
	}
}

static int32 FBC=0;

static void RenderSound(void)
{
	int32 end, start;
	int32 x;

	start=FBC;
	end=(SOUNDTS<<16)/soundtsinc;
	if(end<=start)
		return;
	FBC=end;

	if(!(SPSG[0x9]&0x80))
		for(x=start;x<end;x++)
		{
			uint32 t=FDSDoSound();
			t+=t>>1;
			t>>=4;
			Wave[x>>4]+=t; //(t>>2)-(t>>3); //>>3;
		}
}

static void RenderSoundHQ(void)
{
	uint32 x; //mbg merge 7/17/06 - made this unsigned

	if(!(SPSG[0x9]&0x80))
		for(x=FBC;x<SOUNDTS;x++)
		{
			uint32 t=FDSDoSound();
			t+=t>>1;
			WaveHi[x]+=t; //(t<<2)-(t<<1);
		}
		FBC=SOUNDTS;
}

static void HQSync(int32 ts)
{
	FBC=ts;
}

void FDSSound(int c)
{
	RenderSound();
	FBC=c;
}

/*
static DECLFR(FDSBIOSPatch)
{
if(FDSRegs[5]&0x4)
{
X.X=FDSRead4031(0x4031);
FDSWrite(0x4024,X.A);
X.A=X.X;
return(0x60);
}
else
{
return(0x58);
//puts("Write");
}
}
*/

static void FDS_ESI(void)
{
	if(FSettings.SndRate)
	{
		if(FSettings.soundq>=1)
		{
			fdso.cycles=(int64)1<<39;
		}
		else
		{
			fdso.cycles=((int64)1<<40)*FDSClock;
			fdso.cycles/=FSettings.SndRate *16;
		}
	}
	//  fdso.cycles=(int64)32768*FDSClock/(FSettings.SndRate *16);
	SetReadHandler(0x4040,0x407f,FDSWaveRead);
	SetWriteHandler(0x4040,0x407f,FDSWaveWrite);
	SetWriteHandler(0x4080,0x408A,FDSSWrite);
	SetReadHandler(0x4090,0x4092,FDSSRead);

	//SetReadHandler(0xE7A3,0xE7A3,FDSBIOSPatch);
}

void FDSSoundReset(void)
{
	memset(&fdso,0,sizeof(fdso));
	FDS_ESI();
	GameExpSound.HiSync=HQSync;
	GameExpSound.HiFill=RenderSoundHQ;
	GameExpSound.Fill=FDSSound;
	GameExpSound.RChange=FDS_ESI;
}

static DECLFW(FDSWrite)
{
	//extern int scanline;
	//FCEU_printf("$%04x:$%02x, %d\n",A,V,scanline);
	switch(A)
	{
	case 0x4020:
		// Timer IRQ reload value low - not affected by $4023.0
		X6502_IRQEnd(FCEU_IQEXT);
		IRQLatch&=0xFF00;
		IRQLatch|=V;
		break;
	case 0x4021:
		// Timer IRQ reload value high - not affected by $4023.0
		X6502_IRQEnd(FCEU_IQEXT);
		IRQLatch&=0xFF;
		IRQLatch|=V<<8;
		break;
	case 0x4022:
		// Timer IRQ control - only works if disk registers enabled ($4023.0)
		X6502_IRQEnd(FCEU_IQEXT);
		if(FDSRegs[3]&0x1)  // Disk registers enabled
		{
			IRQCount=IRQLatch;
			IRQa=V&3;
		}
		else
		{
			// If disk registers disabled, stop timer IRQ
			IRQa&=~2;
			IRQCount=0;
		}
		break;
	case 0x4023:
		// Master I/O enable
		// Bit 0: Enable disk I/O registers (0=disabled, 1=enabled)
		// Bit 1: Enable sound I/O registers (0=disabled, 1=enabled)
		// Bit 7: Unknown (BIOS writes $00 then $83)
		if(!(V&0x1))  // Disabling disk registers
		{
			// Stop timer IRQ immediately
			IRQa&=~2;
			IRQCount=0;
			X6502_IRQEnd(FCEU_IQEXT);
			// Also stop disk transfer IRQ
			X6502_IRQEnd(FCEU_IQEXT2);
		}
		FDSRegs[3]=V;
		break;
	case 0x4024:
		// Write data register - resets byte transfer flag and acknowledges disk IRQ
		ByteTransferFlag = 0;
		X6502_IRQEnd(FCEU_IQEXT2);
		if(InDisk!=255 && !(FDSRegs[5]&0x4) && (FDSRegs[3]&0x1))
		{
			if(DiskPtr>=0 && DiskPtr<65500)
			{
				if(writeskip) writeskip--;
				else if(DiskPtr>=2)
				{
					DiskWritten=1;
					diskdata[InDisk][DiskPtr-2]=V;
				}
			}
		}
		break;
	case 0x4025:
		// FDS Control - acknowledges disk IRQ
		X6502_IRQEnd(FCEU_IQEXT2);
		if(InDisk!=255)
		{
			// Bit 0: Transfer Reset (1 = Reset transfer timing to initial state)
			// Bit 1: Drive Motor Control (0 = start, 1 = stop) - spec says bit 1, but code uses bit 6
			// Bit 2: Transfer Mode (0 = write, 1 = read)
			// Bit 3: Nametable Arrangement (0 = Horizontal, 1 = Vertical)
			// Bit 4: CRC Transfer Control (1 = transfer CRC value)
			// Bit 5: Unknown, always set to '1' by BIOS/games
			// Bit 6: CRC Enabled (0 = disable/reset, 1 = enable)
			// Bit 7: Interrupt Enabled (1 = Generate IRQ on byte transfer flag)
			
			// Motor control logic (original code uses bit 6 for motor, keeping for compatibility)
			if(!(V&0x40))  // Motor starting (bit 6 clear)
			{
				if(FDSRegs[5]&0x40 && !(V&0x10))
				{
					DiskSeekIRQ=200;
					DiskPtr-=2;
				}
				if(DiskPtr<0) DiskPtr=0;
			}
			
			// Nametable arrangement
			setmirror(((V>>3)&1)^1);
			
			// CRC reset
			if(!(V&0x4)) writeskip=2;  // Reset CRC when bit 4 is cleared
			
			// Transfer reset (bit 0)
			if(V&0x2) {DiskPtr=0;DiskSeekIRQ=200;}  // Transfer reset (bit 1)
			if(V&0x40) DiskSeekIRQ=200;  // Motor stop (bit 6)
		}
		FDSRegs[5]=V;
		break;
	case 0x4026:
		// External connector output (open-collector with pull-ups)
		// Bits 0-6: Output to expansion terminal
		// Bit 7: Has pull-up (always high when output)
		// Setting $4025.D5 to 0 alters bits 1 and 2
		if(!(FDSRegs[5]&0x20))  // If $4025.D5 is 0
		{
			// Alter bits 1 and 2 (TODO: exact behavior needs testing)
			V = (V & ~0x06) | ((V & 0x06) ^ 0x06);
		}
		FDSReg4026 = V;
		break;
	}
	if(A != 0x4026)  // Don't store $4026 in FDSRegs array
		FDSRegs[A&7]=V;
}

static void FreeFDSMemory(void)
{
	int x;

	for(x=0;x<TotalSides;x++)
		if(diskdata[x])
		{
			free(diskdata[x]);
			diskdata[x]=0;
		}
}

static int SubLoad(FCEUFILE *fp)
{
	struct md5_context md5;
	uint8 header[16];
	int x;

	FCEU_fread(header,16,1,fp);

	if(memcmp(header,"FDS\x1a",4))
	{
		if(!(memcmp(header+1,"*NINTENDO-HVC*",14)))
		{
			long t;
			t=FCEU_fgetsize(fp);
			if(t<65500)
				t=65500;
			TotalSides=t/65500;
			FCEU_fseek(fp,0,SEEK_SET);
		}
		else
			return(0);
	} 
	else
		TotalSides=header[4];

	md5_starts(&md5);

	if(TotalSides>8) TotalSides=8;
	if(TotalSides<1) TotalSides=1;

	for(x=0;x<TotalSides;x++)
	{
		diskdata[x]=(uint8 *)FCEU_malloc(65500);
		if(!diskdata[x])
		{
			int zol;
			for(zol=0;zol<x;zol++)
				free(diskdata[zol]);
			return 0;
		}
		FCEU_fread(diskdata[x],1,65500,fp);
		md5_update(&md5,diskdata[x],65500);
	}
	md5_finish(&md5,GameInfo->MD5.data);
	return(1);
}

static void PreSave(void)
{
	int x;

	//if(DiskWritten)
	for(x=0;x<TotalSides;x++)
	{
		int b;
		for(b=0; b<65500; b++)
			diskdata[x][b] ^= diskdatao[x][b];
	}
}

static void PostSave(void)
{
	int x;

	//if(DiskWritten)
	for(x=0;x<TotalSides;x++)
	{
		int b;

		for(b=0; b<65500; b++)
			diskdata[x][b] ^= diskdatao[x][b];
	} 

}

int FDSLoad(const char *name, FCEUFILE *fp)
{
	FILE *zp;
	int x;
	char *fn;

	FCEU_fseek(fp,0,SEEK_SET);

	if(!SubLoad(fp)) 
		return(0);

#ifndef GEKKO
	fn = strdup(FCEU_MakeFName(FCEUMKF_FDSROM,0,0).c_str());

	if(!(zp=FCEUD_UTF8fopen(fn,"rb")))  
	{
		FCEU_PrintError("FDS BIOS ROM image missing: %s", FCEU_MakeFName(FCEUMKF_FDSROM,0,0).c_str());
		FreeFDSMemory();
		free(fn);
		return 0;
	}

	free(fn);

	fseek( zp, 0L, SEEK_END );
	if (ftell( zp ) != 8192 ) {
		fclose(zp);
		FreeFDSMemory();
		FCEU_PrintError("FDS BIOS ROM image incompatible: %s", FCEU_MakeFName(FCEUMKF_FDSROM,0,0).c_str());
		return 0;
	}
	fseek( zp, 0L, SEEK_SET );

	if(fread(FDSBIOS,1,8192,zp)!=8192)
	{
		fclose(zp);
		FreeFDSMemory();
		FCEU_PrintError("Error reading FDS BIOS ROM image.");
		return 0;
	}

	fclose(zp);
#elif defined(_XBOX)
	// Xbox-specific BIOS loading
	// Try multiple possible paths for the FDS BIOS
	const char* biosPaths[] = {
		"game:\\disksys.rom",
		"game:\\bios\\disksys.rom",
		"hdd1:\\fce360-enhanced\\disksys.rom",
		NULL
	};
	
	int biosLoaded = 0;
	for(int i = 0; biosPaths[i] != NULL; i++)
	{
		zp = fopen(biosPaths[i], "rb");
		if(zp)
		{
			fseek(zp, 0L, SEEK_END);
			long size = ftell(zp);
			fseek(zp, 0L, SEEK_SET);
			
			if(size == 8192)
			{
				if(fread(FDSBIOS, 1, 8192, zp) == 8192)
				{
					biosLoaded = 1;
					fclose(zp);
					break;
				}
			}
			fclose(zp);
		}
	}
	
	if(!biosLoaded)
	{
		FCEU_PrintError("FDS BIOS ROM image missing. Please place 'disksys.rom' in game:\\ or game:\\roms\\");
		FreeFDSMemory();
		return 0;
	}
#endif

	if (!disableBatteryLoading)
	{
		FCEUFILE *tp;
		char *fn=strdup(FCEU_MakeFName(FCEUMKF_FDS,0,0).c_str());

		int x;
		for(x=0;x<TotalSides;x++)
		{
			diskdatao[x]=(uint8 *)FCEU_malloc(65500);
			memcpy(diskdatao[x],diskdata[x],65500);
		}
#ifndef GEKKO
		if((tp=FCEU_fopen(fn,0,"wb",0)))
		{
			FreeFDSMemory();
			if(!SubLoad(tp))
			{
				FCEU_PrintError("Error reading auxillary FDS file.");
				free(fn);
				return(0);
			}
			FCEU_fclose(tp);
			DiskWritten=1;  /* For save state handling. */
		}
		free(fn);
#endif
	}
#ifndef GEKKO
	extern char LoadedRomFName[2048];
	strcpy(LoadedRomFName,name); //For the debugger list
#endif
	GameInfo->type=GIT_FDS;
	GameInterface=FDSGI;
	isFDS = true;

	SelectDisk=0;
	InDisk=255;

	ResetExState(PreSave,PostSave);
	FDSSoundStateAdd();

	for(x=0;x<TotalSides;x++)
	{
		char temp[5];  
		sprintf(temp,"DDT%d",x);
		AddExState(diskdata[x],65500,0,temp);
	}

	AddExState(FDSRAM,32768,0,"FDSR");
	AddExState(FDSRegs,sizeof(FDSRegs),0,"FREG");
	AddExState(&FDSReg4026,1,0,"F4026");
	AddExState(CHRRAM,8192,0,"CHRR");
	AddExState(&IRQCount, 4, 1, "IRQC");
	AddExState(&IRQLatch, 4, 1, "IQL1");
	AddExState(&IRQa, 1, 0, "IRQA");
	AddExState(&writeskip,1,0,"WSKI");
	AddExState(&DiskPtr,4,1,"DPTR");
	AddExState(&DiskSeekIRQ,4,1,"DSIR");
	AddExState(&SelectDisk,1,0,"SELD");
	AddExState(&InDisk,1,0,"INDI");
	AddExState(&DiskWritten,1,0,"DSKW");
	AddExState(&ByteTransferFlag,1,0,"BTF");

	ResetCartMapping();
	SetupCartCHRMapping(0,CHRRAM,8192,1);
	SetupCartMirroring(0,0,0);
	memset(CHRRAM,0,8192);
	memset(FDSRAM,0,32768);

	FCEU_printf(" Sides: %d\n\n",TotalSides);

	FCEUI_SetVidSystem(0);

	return 1;
}

void FDSClose(void)
{
#ifdef GEKKO
	FreeFDSMemory();
	return;
#endif
	FILE *fp;
	int x;
	isFDS = false;
	char *fn=strdup(FCEU_MakeFName(FCEUMKF_FDS,0,0).c_str());

	if(!DiskWritten) return;

	if(!(fp=FCEUD_UTF8fopen(fn,"wb")))
	{
		free(fn);
		return;
	}
	free(fn);

	for(x=0;x<TotalSides;x++)
	{
		if(fwrite(diskdata[x],1,65500,fp)!=65500) 
		{
			FCEU_PrintError("Error saving FDS image!");
			fclose(fp);
			return;
		}
	}
	FreeFDSMemory();
	fclose(fp);
}
